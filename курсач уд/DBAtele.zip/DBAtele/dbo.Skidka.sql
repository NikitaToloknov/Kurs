﻿CREATE TABLE [dbo].[Скидка]
(
	[Колличество заказов] INT NOT NULL PRIMARY KEY, 
    [Скидка] INT NULL
)
