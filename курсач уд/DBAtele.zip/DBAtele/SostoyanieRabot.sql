﻿CREATE TABLE [dbo].[Состояние]
(
	[ID заказа] INT NOT NULL PRIMARY KEY, 
    [Примечания] NVARCHAR(50) NULL, 
    [Состояние] BIT NULL
)
